HoraLife Store Addresses Postman Collection

Import the collection JSON and use your existing HoraLife Local environment.

Required environment variables:
- baseUrl
- accessToken

Store the JWT in accessToken without the 'Bearer ' prefix.

Run "Address CRUD Flow" in order. The collection automatically saves:
- shippingAddressAId
- shippingAddressBId
- billingAddressId

The separate "Fresh User Default Rule" should be run only with a user who has
no existing Shipping address. It verifies that the first Shipping address
becomes default even when the request sends isDefault=false.

You can move the imported folders into:
HoraLife API > Store > Addresses
